import string, random

from django.conf.urls import url
from short.models import URL
import redis
from django.http import JsonResponse
from django.contrib.sites.shortcuts import get_current_site
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect

rds = redis.Redis(host='localhost', port=6379, db=0)

def shortit(long_url):
    N = 7
    s = string.ascii_uppercase + string.ascii_lowercase + string.digits
    url_id = ''.join(random.choices(s, k=N))
    if not URL.objects.filter(hash=url_id).exists():
        create = URL.objects.create(full_url=long_url, hash=url_id)
        return url_id
    else:
        shortit(url)


@csrf_exempt
def short_url(request):
    long_url = request.POST.get("url")
    # get the unique id for long url
    hash = shortit(long_url)
    # get the host url
    current_site = get_current_site(request)
    data = {
        "success": True,
        "id": hash,
        "link": "http://{}/{}".format(current_site, hash),
        "long_url": long_url
    }
    return JsonResponse(data)

def redirector(request,hash_id=None):
    hash_code = rds.get(hash_id)
    if hash_code is not None:
        return redirect(hash_code.decode('ascii'))

    if URL.objects.filter(hash=hash_id).exists():
        url = URL.objects.get(hash=hash_id)
        # set the value in redis for faster access
        rds.set(hash_id,url.full_url)
        # redirect the page to the respective url
        return redirect(url.full_url)
    else:
        # if the give key not in redis and db
        return JsonResponse({"success":False})