from django.apps import AppConfig


class ShortConfig(AppConfig):
    name = 'short'
